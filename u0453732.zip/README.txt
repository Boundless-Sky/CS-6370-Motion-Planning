
Author: Justin Ngo
Date: 9/14/2019

University of Utah
CS 6370 Motion Planning

Project 1: Graph Search

****** IMPORTANT FILES ******
map0.txt
map1.txt
map2.txt
graph_search.py
run_graph_search.py

****** HOW TO USE ********
*assumes all files are in one folder
*easiest is to use an IDE like spyder, vscode or pycharm

To run, open up run_graph_search.py and hit run in the IDE. 
edit variables in the main function to change what tests to run.

Variables to alter:
test_map - changes what map to run test on. 
	example: './map0.txt'
		 './map1.txt' ... etc

action_type - changes what types of actions that can be taken. 
	0 = original actions [u d l r]
	1 = orig reversed, 
	2 = orig w/diag, 
	3 = nonholonmic

heuristic - changes what heurstic is used in A*
	0 = uninformed
	1 = euclidean
	2 = manhattan

To run certain algorithms just uncomment the approriate line in the file (run_graph_search)
Each algorithm has a preceeding comment " ---- section # algorith name ----- "
just comment/uncomment the desired algorithm and hit run.

enjoy!

****** Additional details ******
!!! Changing transion function and actions !!!
note that when choosing 3 in the action_type (nonholonomic) the code changes the correct transition function and action. 
Otherwise, use the action_type as normal. 

