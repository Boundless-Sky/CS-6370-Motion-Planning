import graph_search


def run_dfs(map_path, actions=graph_search._ACTIONS, max_depth = None):
    g = graph_search.GridMap(map_path)
    
    if actions is graph_search._ACTIONS_NONHOLONOMIC:
        res = graph_search.dfs(g.init_pos, g.nonholonomic_transition, g.is_goal, actions, max_depth)
    else:
        res = graph_search.dfs(g.init_pos, g.transition, g.is_goal, actions, max_depth)
    
    g.display_map(res[0][0], res[1])
    
    print('Path:')
#    print(res[0][0])
    print(len(res[0][0]))
    print('Visited:')
    print(len(res[1]))
#    print(res[1])

def run_bfs(map_path, actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    
    if actions is graph_search._ACTIONS_NONHOLONOMIC:
        res = graph_search.bfs(g.init_pos, g.nonholonomic_transition, g.is_goal, actions)
    else:
        res = graph_search.bfs(g.init_pos, g.transition, g.is_goal, actions)
    
    g.display_map(res[0][0], res[1])
    
    print('Path:')
#    print(res[0][0])
    print(len(res[0][0]))
    print('Visited:')
    print(len(res[1]))
#    print(res[1])

def run_ucs(map_path, actions = graph_search._ACTIONS_2):
    g = graph_search.GridMap(map_path)
    
    if actions is graph_search._ACTIONS_NONHOLONOMIC:
        res = graph_search.uniform_cost_search(g.init_pos, g.nonholonomic_transition, g.is_goal, actions)
    else:
        res = graph_search.uniform_cost_search(g.init_pos, g.transition, g.is_goal, actions)
    
    g.display_map(res[0][0], res[1])
    
    print('Path:')
#    print(res[0][0])
    print(len(res[0][0]))
    print('Visited:')
    print(len(res[1]))
#    print(res[1])

def run_As(map_path, actions=graph_search._ACTIONS_2, heuristic = 0):
    g = graph_search.GridMap(map_path)

    if heuristic == 0:
        map_h = g.uninformed_heuristic
    elif heuristic == 1:
        map_h = g.euclidean_heuristic
    elif heuristic == 2:
        map_h = g.manhattan_heuristic
            
    if actions is graph_search._ACTIONS_NONHOLONOMIC:
        res = graph_search.a_star_search(g.init_pos, g.nonholonomic_transition, g.is_goal, actions, map_h)
    else:
        res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions, map_h)
        
    g.display_map(res[0][0], res[1])
    
    print('Path:')
#    print(res[0][0])
    print(len(res[0][0]))
    print('Visited:')
    print(len(res[1]))
#    print(res[1])

if __name__ == '__main__':
    test_map = './map0.txt'
    action_type = 0 # 0 = orig, 1 = orig reversed, 2 = orig w/diag, 3 = nonholonmic
    
    # for A* search only
    heuristic = 2 # 0 = uninformed, 1 = euclidean, 2 = manhattan
    
    if action_type == 0:
        actions = graph_search._ACTIONS # original action set U, D, L, R
    elif action_type == 1:
        actions = graph_search._ACTIONS_REVERSED # action set reversed
    elif action_type == 2:
        actions = graph_search._ACTIONS_2 # original action w/diagonals
    elif action_type == 3:
        actions = graph_search._ACTIONS_NONHOLONOMIC # nonholonomic actions
    
    # ---- Section 1 - Depth First Search / Iterative Deepening DFS ----
    run_dfs(test_map, actions, max_depth = 30) # just DFS
#    run_dfs(test_map, actions, max_depth = 25) # include max_depth to use IDDFS
    
    # ---- Section 2 - Breadth First Search ----
#    run_bfs(test_map, actions)

    # ---- Section 3 - Uniform Cost Search ----
#    run_ucs(test_map, actions)
    
    # ---- Section 4 - A* Search ----
#    run_As(test_map, actions, heuristic)
    
    # ---- Section 5 - Nonholonomic robot ----
    