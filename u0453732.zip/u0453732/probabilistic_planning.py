# -*- coding: utf-8 -*-
#!/usr/bin/env python
"""
Created on Sat Oct 26 15:00:22 2019

@author: Justin Ngo
"""
import sys
import numpy as np
import matplotlib.pyplot as plotter
import time

_DEBUG = False
_DEBUG_END = True

_ACTIONS = ['u', 'd', 'l', 'r'] # original action set
_ACTIONS_2 = ['u', 'd', 'l', 'r', 'ne', 'nw', 'sw', 'se']


# state representation (y[row],x[col],t)
_T = 2 # this is theta
_X = 1
_Y = 0

# transition probability 
_CA = 0 # correct action
_NA = 1 # neighbor / diagonal
_OA = 2 # orthogonal

tp0 = (1, 0 , 0)
tp1 = (0.8, 0, 0.1)
tp2 = (0.6, 0, 0.2)
tp3 = (0.8, 0.1, 0)
tp4 = (0.7, 0.1, 0.05)

_GOAL_COLOR = 0.75
_INIT_COLOR = 0.25
_PATH_COLOR_RANGE = _GOAL_COLOR - _INIT_COLOR
_VISITED_COLOR = 0.9


class GridMap:
    '''
    Class to hold a grid map for navigation. Reads in a map.txt file of the format
    0 - free cell, x - occupied cell, g - goal location, i - initial location.
    Additionally provides a simple transition model for grid maps and a convience function
    for displaying maps.
    '''

    def __init__(self, map_path=None):
        '''
        Constructor. Makes the necessary class variables. Optionally reads in a provided map
        file given by map_path.

        map_path (optional) - a string of the path to the file on disk
        '''
        self.rows = None
        self.cols = None
        self.goal = None
        self.init_pos = None
        self.occupancy_grid = None
        if map_path is not None:
            self.read_map(map_path)

    def read_map(self, map_path):
        '''
        Read in a specified map file of the format described in the class doc string.

        map_path - a string of the path to the file on disk
        '''
        map_file = open(map_path, 'r')
        lines = [l.rstrip().lower() for l in map_file.readlines()]
        map_file.close()
        self.rows = len(lines)
        self.cols = max([len(l) for l in lines])
        if _DEBUG:
            print('rows', self.rows)
            print('cols', self.cols)
            print(lines)
        self.occupancy_grid = np.zeros((self.rows, self.cols), dtype=np.bool)
        for r in range(self.rows):
            for c in range(self.cols):
                if lines[r][c] == 'x':
                    self.occupancy_grid[r][c] = True
                if lines[r][c] == 'g':
                    self.goal = (r, c)
                elif lines[r][c] == 'i':
                    self.init_pos = (r, c, 0)

    def is_goal(self, s):
        '''
        Test if a specifid state is the goal state

        s - tuple describing the state as (row, col) position on the grid.

        Returns - True if s is the goal. False otherwise.
        '''
        return (s[_X] == self.goal[_X] and
                s[_Y] == self.goal[_Y])

    def transition(self, s, a, sim = False, tp = (1,0,0)):
        '''
        Transition function for the current grid map.

        s - tuple describing the state as (row, col) position on the grid.
        a - the action to be performed from state s

        returns - s_prime, the state transitioned to by taking action a in state s.
        If the action is not valid (e.g. moves off the grid or into an obstacle)
        returns the current state.
        
        Justin Ngo 10/26/2019 - Planning with uncertainity update
        Simulator = False (default)
            - this variable toggles 2 version
            - False: Returns a model of probability distributions a list of 2-tuples, each tuple holds
            a probability and state. 
            - True: Returns a state according to transition probabilites
            the default is 80% making the correct attion and 10% chance in either direction perpendicular to commanded action
        
        Transition probabilites 'tp' = tuple(correct action, neighbor action, orthogonal action)
        i.e. neighbor action --> up-left, up-right for commanded action 'up'
        i.e. orthogonal aciton --> right or left given 'up' command
        '''
        prob_array = [tp[_CA], tp[_NA], tp[_NA], tp[_OA], tp[_OA]] 
        if sim == False: # return the list of tuples/states 
            next_states = []
            list_a = self.probable_actions(a)
            for action in list_a:
                next_states.append(self.state_move(s, action))
            return tuple(zip(next_states, prob_array))
        else:
            # check if probability is = 1
            if sum(prob_array) != 1:
                print('probabilites need to sum to 1, tp=(correct_action, neighbor action (x2), orthogonal action (x2))')
                sys.exit()
            if a == None:
                return s
            else:
                rand_a = np.random.choice(self.probable_actions(a), p = prob_array)
                return self.state_move(s, rand_a)
            
    def state_move(self,s,a):
        new_pos = list(s[:])
        # Ensure action stays on the board
        if a == 'u':
            if s[_Y] > 0:
                new_pos[_Y] -= 1
        elif a == 'd':
            if s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
        elif a == 'l':
            if s[_X] > 0:
                new_pos[_X] -= 1
        elif a == 'r':
            if s[_X] < self.cols - 1:
                new_pos[_X] += 1
        # added diagonal moves Justin Ngo 9/7/2019
        elif a == 'ne':
            if s[_X] < self.cols - 1 and s[_Y] > 0:
                new_pos[_Y] -= 1
                new_pos[_X] += 1
        elif a == 'nw':
            if s[_X] > 0 and s[_Y] > 0:
                new_pos[_Y] -= 1
                new_pos[_X] -= 1
        elif a == 'sw':
            if s[_X] > 0 and s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
                new_pos[_X] -= 1
        elif a == 'se':
            if s[_X] < self.cols - 1 and s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
                new_pos[_X] += 1
        else:
            print('Unknown action:', str(a))

        # Test if new position is clear
        if self.occupancy_grid[new_pos[0], new_pos[1]]:
            s_prime = tuple(s)
        else:
            s_prime = tuple(new_pos)
        return s_prime
    
    def probable_actions(self, a):
        """
        Returns a list of probable actions
        i.e. given the command 'r' we can go 'UR', 'DR', 'U', 'D'
        """
        # in the form [correct action, diagonal action (x2), orthogonal aciton (x2)]
        probable_a = []   
        
        if a == 'u':
            probable_a = ['u', 'ne', 'nw', 'r', 'l']
        elif a == 'd':
            probable_a = ['d', 'se', 'sw', 'r', 'l']
        elif a == 'l':
            probable_a = ['l', 'nw', 'sw', 'u', 'd']
        elif a == 'r':
            probable_a = ['r', 'ne', 'se', 'u', 'd']
        elif a == 'ne':
            probable_a = ['ne', 'u', 'r', 'se', 'nw']
        elif a == 'nw':
            probable_a = ['nw', 'u', 'l', 'ne', 'sw']
        elif a == 'se':
            probable_a = ['se', 'd', 'r', 'ne', 'sw']
        elif a == 'sw':
            probable_a = ['sw', 'd', 'l', 'se', 'nw']
            
        return probable_a
    
    def display_map(self, path=[], visited={}, filename=None):
        '''
        Visualize the map read in. Optionally display the resulting plan and visisted nodes

        path - a list of tuples describing the path take from init to goal
        visited - a set of tuples describing the states visited during a search
        filename - relative path to file where image will be saved
        '''
        display_grid = np.array(self.occupancy_grid, dtype=np.float32)

        # Color all visited nodes if requested
        for v in visited:
            display_grid[v[0], v[1]] = _VISITED_COLOR
        # Color path in increasing color from init to goal
        for i, p in enumerate(path):
            disp_col = _INIT_COLOR + _PATH_COLOR_RANGE * (i + 1) / len(path)
            display_grid[p[0], p[1]] = disp_col

#        display_grid[self.init_pos[0], self.init_pos[1]] = _INIT_COLOR
#        display_grid[self.goal] = _GOAL_COLOR

        # Plot display grid for visualization
        imgplot = plotter.imshow(display_grid)
        # Set interpolation to nearest to create sharp boundaries
        imgplot.set_interpolation('nearest')
        # Set color map to diverging style for contrast
        imgplot.set_cmap('Spectral')
        if filename is not None:
            plotter.savefig(filename)
        plotter.show()
        
    def display_actionpath(self, action_grid):
        plotter.figure(0)
        display_grid = np.array(self.occupancy_grid, dtype = np.float32)
        for (r,c),v in np.ndenumerate(action_grid):
            if self.occupancy_grid[r][c] == True:
                display_grid[r,c] = 1 
            else:
                plotter.text(c,r,v,horizontalalignment = 'center', verticalalignment = 'center', fontweight = 'bold', fontsize = 20)
                display_grid[r,c] = 0
        display_grid[self.goal] = _GOAL_COLOR
         # Plot display grid for visualization
        imgplot = plotter.imshow(display_grid)
        # Set interpolation to nearest to create sharp boundaries
        imgplot.set_interpolation('nearest')
        # Set color map to diverging style for contrast
        imgplot.set_cmap('Spectral')
#        x,y = np.meshgrid(np.arange(display_grid.shape[1]), np.arange(display_grid.shape[0]))
#        m = np.c_[x[display_grid.astype(bool)],y[display_grid.astype(bool)]]
#        for pos in m:
#            self.rect(pos)
        for r in range(self.rows):
            for c in range(self.cols):
                pos = np.array([c,r])
                self.rect(pos)
        plotter.show()
    
    def display_value(self, value):
        plotter.figure(1)
        display_grid = np.array(self.occupancy_grid, dtype = np.float32)
        for (r,c),v in np.ndenumerate(value):
            if self.occupancy_grid[r][c] == True:
                display_grid[r,c] = 1 
            else:
                plotter.text(c,r,"%.2f" % v,horizontalalignment = 'center', verticalalignment = 'center', fontweight = 'bold', fontsize = 12)
                display_grid[r,c] = 0
        display_grid[self.goal] = _GOAL_COLOR
         # Plot display grid for visualization
        imgplot = plotter.imshow(display_grid)
        # Set interpolation to nearest to create sharp boundaries
        imgplot.set_interpolation('nearest')
        # Set color map to diverging style for contrast
        imgplot.set_cmap('Spectral')
#        x,y = np.meshgrid(np.arange(display_grid.shape[1]), np.arange(display_grid.shape[0]))
#        m = np.c_[x[display_grid.astype(bool)],y[display_grid.astype(bool)]]
#        for pos in m:
#            self.rect(pos)
        for r in range(self.rows):
            for c in range(self.cols):
                pos = np.array([c,r])
                self.rect(pos)
        plotter.show()
    
    def rect(self,pos):
        r = plotter.Rectangle(pos-0.5, 1,1, facecolor="none", edgecolor="k", linewidth=2)
        plotter.gca().add_patch(r)
        
    def uninformed_heuristic(self, s):
        '''
        Example of how a heuristic may be provided. This one is admissable, but dumb.

        s - tuple describing the state as (row, col) position on the grid.

        returns - floating point estimate of the cost to the goal from state s
        '''
        return 0.0
    
class SearchNode:
    def __init__(self, s, A, parent=None, parent_action=None, cost=0):
        '''
        s - the state defining the search node
        A - list of actions
        parent - the parent search node
        parent_action - the action taken from parent to get to s
        '''
        self.parent = parent
        self.cost = cost
        self.parent_action = parent_action
        self.state = s[:]
        self.actions = A[:]

    def __str__(self):
        '''
        Return a human readable description of the node
        '''
        return str(self.state) + ' ' + str(self.actions) + ' ' + str(self.parent) + ' ' + str(self.parent_action)

    def __lt__(self, other):
        return self.cost < other.cost
    

def backpath(node):
    '''
    Function to determine the path that lead to the specified search node

    node - the SearchNode that is the end of the path

    returns - a tuple containing (path, action_path) which are lists respectively of the states
    visited from init to goal (inclusive) and the actions taken to make those transitions.
    '''
    path = []
    action_path = []
    # Justin Ngo 8/31/2019
    n = node
    while n.parent is not None:
        path.insert(0, n.state)
        action_path.insert(0, n.parent_action)
        n = n.parent
        if n.parent is None:
            path.insert(0, n.state)
            action_path.insert(0, None)
    return (path, action_path)

def bfs(init_state, f, is_goal, actions, tps = (1,0,0)):
    '''
    Perform breadth first search on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''
    # Justin Ngo - 9/2/2019
    frontier = []  # Search (FIFO => Queue, like standing in line)
    node_0 = SearchNode(init_state, actions)
    visited = set()  # make a new list to keep track of nodes you pop out
    frontier.append(node_0)  # remember you pop a node to reveal children if any
    while len(frontier) > 0:
        # This is BFS is FIFO
        node_i = frontier.pop(0)
        if node_i.state not in visited:
            visited.add(node_i.state)
            if is_goal(node_i.state):
                return (backpath(node_i), visited)
            else:
                for an_action in actions:
                    s_prime = f(node_i.state, an_action, sim = True, tp = tps)  # s_prime = next state
                    n_prime = SearchNode(s_prime, actions, node_i, an_action)
                    frontier.append(n_prime)
    print('Visited List when goal not found:')
    print(visited)
    return None

def run_bfs(map_path, actions=_ACTIONS, display_stochastic = False, trans_prob = tp0):
    # find the path first (deterministic)
    g = GridMap(map_path)
    res = bfs(g.init_pos, g.transition, g.is_goal, actions)
      
    n = g.init_pos
    sim = []
    for a in res[0][1]:
        s_prime = g.transition(n, a, True, trans_prob)
        sim.append(s_prime)
        n = s_prime
    
    if display_stochastic == False:
        g.display_map(res[0][0], res[1])
        print('Path:')
        #    print(res[0][0])
        print(len(res[0][0]))
        print('Visited:')
        print(len(res[1]))
        #    print(res[1])
        print('Action Path:')
        print(res[0][1])
    else:
        g.display_map(sim)

def run_value_iteration(map_path, actions = _ACTIONS, trans_prob = tp0, discount = 0.8, scenario = 0):
    g = GridMap(map_path)
    
    # NOTE!! Making an array = another array just shares the memory location, not make a new array
    value = np.zeros((g.rows, g.cols))
    action_grid = np.zeros((g.rows, g.cols), dtype = np.dtype('U2')) # strings
    """
    Note by default unicode_ is a string length of 1
    np.dtyple(np.unicode_, 16) < changes length to 16
    or
    dtype = 'U16'  
    or 
    np.dtype = '<U16', the < or > refers to endianess (MSB/ LSB)
    array([''field name'], dtype = '<U100') or Y = np.empty((N,1), dtype = np.dtype('U100'))
    """
    reward_grid = np.zeros((g.rows, g.cols))
    
    
     # scenario = 0 => goal +10, everything else = 0
    # scenario = 1 => goal +1, everything else = 0
    # scenario = 2 => goal +10, everything else = -1
    # scenario = 3 => goal +10, corners -5, everything else = 0
    
    for r in range(g.rows):
        for c in range(g.cols):
            if g.occupancy_grid[r][c] == True:
                value[r][c] = None
                reward_grid[r][c] = None
            else:
                if scenario == 2:    
                    reward_grid[r][c] = -1
                else:
                    reward_grid[r][c] = 0
                
    
    # NOTE!! Making an array = another array just shares the memory location, not make a new array
    if scenario == 3: #corners
        reward_grid[0,0] = -5
        reward_grid[0,g.cols-1] = -5
        reward_grid[g.rows-1, 0] = -5
        reward_grid[g.rows-1, g.cols-1] = -5
    if scenario == 0 or scenario == 2 or scenario == 3:
        reward_grid[g.goal[_Y]][g.goal[_X]] = 10    
    elif scenario == 1:
        reward_grid[g.goal[_Y]][g.goal[_X]] = 1
    
    prev_value = reward_grid.copy()

    max_change = 10000
    epsilon = 0.005
    iterations = 0
    t0 = time.time()
    while max_change > epsilon:
        for r in range(g.rows):
            for c in range(g.cols):
                if g.occupancy_grid[r][c] == True:
                    continue
                else:
                    # for every action in the action set
                    value_action = []
                    for a in actions:
                        state = (r, c, 0)
                        probable_actions = g.transition(state, a, sim = False, tp = trans_prob)
                        sumPV = 0
                        for (i,j) in probable_actions: #state, probability
#                            sumPV = sumPV + prev_value[i[_Y]][i[_X]]*j
#                        v = reward_grid[r][c] + discount*sumPV
                            sumPV = sumPV + j*(reward_grid[r][c] + discount*prev_value[i[_Y]][i[_X]]) # more generic
                        v = sumPV
                        value_action.append((v, a))
                    # save the best value for the given action 
                    val, act = max(value_action, key = lambda i : i[0])
                    action_grid[r][c] = act 
                    value[r][c]= val
        max_change = np.nanmax(np.absolute(np.subtract(value, prev_value)))
        prev_value = value.copy()
        iterations += 1
        
    t1 = time.time()
    print("Value Iteration Time", t1 - t0)
    # styling up the grid
    action_grid[g.goal[_Y]][g.goal[_X]] = 'G' 
    
    # if the value is zero then just remove the actions because it isn't meaningful
    where_zero = np.argwhere(value == 0)
    for wz in where_zero:
        action_grid[wz[0],wz[1]] = ''
    
    g.display_value(value)
    g.display_actionpath(action_grid)
    
    print("Iterations:", iterations)
    
def run_policy_iteration(map_path, actions = _ACTIONS, trans_prob = tp0, discount = 0.8, initial_policy = None):
    g = GridMap(map_path)
    
    # NOTE!! Making an array = another array just shares the memory location, not make a new array
    value = np.zeros((g.rows, g.cols))
    action_grid = np.zeros((g.rows, g.cols), dtype = np.dtype('U2')) # strings
    reward_grid = np.zeros((g.rows, g.cols))
    
    for r in range(g.rows):
        for c in range(g.cols):
            if g.occupancy_grid[r][c] == True:
                value[r][c] = None
                reward_grid[r][c] = None
            else:
                reward_grid[r][c] = 0
                if initial_policy == None:
                    # random 
                    action_grid[r,c] = np.random.choice(actions)
                else:
                    action_grid[r,c] = initial_policy # initial policy
    
    # NOTE!! Making an array = another array just shares the memory location, not make a new array            
    reward_grid[g.goal[_Y]][g.goal[_X]] = 10    
    prev_value = reward_grid.copy()
    
    iterations = 0
    epsilon = 0.005
    improve = True
    t0 = time.time()
    while improve == True:
        # policy evaluation
        max_change = 10000
        while max_change > epsilon:
            for r in range(g.rows):
                for c in range(g.cols):
                    if g.occupancy_grid[r][c] == True:
                        continue
                    else:                  
                        a = action_grid[r,c]
                        state = (r, c, 0)
                        probable_actions = g.transition(state, a, sim = False, tp = trans_prob)
                        sumPV = 0
                        for (i,j) in probable_actions:
                            sumPV = sumPV + j*(reward_grid[r][c] + discount*prev_value[i[_Y]][i[_X]]) # more generic
                        v = sumPV
                        # save the best value for the given action 
                        value[r][c]= v
            max_change = np.nanmax(np.absolute(np.subtract(value, prev_value)))
            prev_value = value.copy()
            
        
        # policy improvement with one-step look ahead
        policy_stable = True
        for r in range(g.rows):
                for c in range(g.cols):
                    last_policy = action_grid[r,c]
                    if g.occupancy_grid[r][c] == True:
                        continue
                    else:
                        # for every action in the action set
                        value_action = []
                        for a in actions:
                            state = (r, c, 0)
                            probable_actions = g.transition(state, a, sim = False, tp = trans_prob)
                            sumPV = 0
                            for (i,j) in probable_actions: #state, probability
                                sumPV = sumPV + j*(reward_grid[r][c] + discount*prev_value[i[_Y]][i[_X]]) # more generic
                            v = sumPV
                            value_action.append((v, a))
                        # save the best value for the given action 
                        val, act = max(value_action, key = lambda i : i[0])
                        if last_policy != act:
                            policy_stable = False
                            action_grid[r][c] = act
        
        iterations += 1
        if policy_stable == True:
            improve = False
    
    t1 = time.time()
    print("Policy Iteration Time", t1 - t0)
    
    # styling up the grid
    action_grid[g.goal[_Y]][g.goal[_X]] = 'G' 
    
    # if the value is zero then just remove the actions because it isn't meaningful
    where_zero = np.argwhere(value == 0)
    for wz in where_zero:
        action_grid[wz[0],wz[1]] = ''
    
    g.display_value(value)
    g.display_actionpath(action_grid)
    
    print("Iterations:", iterations)
    
if __name__ == '__main__':
    test_map = './map1.txt'
    action_type = 0
    
    if action_type == 0:
        actions = _ACTIONS # original action set U, D, L, R
    elif action_type == 1:
        actions = _ACTIONS_2 # original action w/diagonals
 
    # ---- Breadth First Search (MDP) ----
#    run_bfs(test_map, actions, display_stochastic = False, trans_prob = tp1)
    
    # ---- Value Iteration ----
#    run_value_iteration(test_map, actions, trans_prob = tp1, discount = 0.8, scenario = 0)

    # scenario = 0 => goal +10, everything else = 0
    # scenario = 1 => goal +1, everything else = 0
    # scenario = 2 => goal +10, everything else = -1
    # scenario = 3 => goal +10, corners -5, everything else = 0

    # ---- Policy Iteration ----
    run_policy_iteration(test_map, actions, trans_prob = tp1, discount = 0.8, initial_policy = None)
    
    # initial_policy = None ==> random actions
    # or initial_policy can be any action in the action type i.e. 'u', 'd', 'l', 'r'
    
    # note that Policy iteration should run faster than value iteration
    # this is true for map0/2 but for map 1 its slightly slower
    # this is because I'm extracting the policy along with the optimal value at 
    # the same time there for I don't need to recompute the same thing
    # but if the discount factor is higher (you care about future values more)
    # then it does indeed show that policy iteration is quicker
    # NOTE on argmax and max
    # f(2) = 5. max would be 5, arg max is 2
    # in this case, f(action) = value

    # transition probabilites examples
    # correct action, neighbor action, orthogonal to action
    #tp0 = (1, 0 , 0)
    #tp1 = (0.8, 0, 0.1)
    #tp2 = (0.6, 0, 0.2)
    #tp3 = (0.8, 0.1, 0)
    #tp4 = (0.7, 0.1, 0.05)