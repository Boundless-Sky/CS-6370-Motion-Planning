#!/usr/bin/env python
'''
Package providing helper classes and functions for performing graph search operations for planning.
'''
import sys
import numpy as np
import heapq
import matplotlib.pyplot as plotter
from math import hypot, sqrt

_DEBUG = False
_DEBUG_END = True

_ACTIONS = ['u', 'd', 'l', 'r'] # original action set
_ACTIONS_REVERSED = ['r', 'l', 'd', 'u']
_ACTIONS_2 = ['u', 'd', 'l', 'r', 'ne', 'nw', 'sw', 'se']
_ACTIONS_NONHOLONOMIC = ['f','l','r'] #forward, spin left, spin right

# state representation (y[row],x[col],t)
_T = 2 # this is theta
_X = 1
_Y = 0

_GOAL_COLOR = 0.75
_INIT_COLOR = 0.25
_PATH_COLOR_RANGE = _GOAL_COLOR - _INIT_COLOR
_VISITED_COLOR = 0.9


class GridMap:
    '''
    Class to hold a grid map for navigation. Reads in a map.txt file of the format
    0 - free cell, x - occupied cell, g - goal location, i - initial location.
    Additionally provides a simple transition model for grid maps and a convience function
    for displaying maps.
    '''

    def __init__(self, map_path=None):
        '''
        Constructor. Makes the necessary class variables. Optionally reads in a provided map
        file given by map_path.

        map_path (optional) - a string of the path to the file on disk
        '''
        self.rows = None
        self.cols = None
        self.goal = None
        self.init_pos = None
        self.occupancy_grid = None
        if map_path is not None:
            self.read_map(map_path)

    def read_map(self, map_path):
        '''
        Read in a specified map file of the format described in the class doc string.

        map_path - a string of the path to the file on disk
        '''
        map_file = open(map_path, 'r')
        lines = [l.rstrip().lower() for l in map_file.readlines()]
        map_file.close()
        self.rows = len(lines)
        self.cols = max([len(l) for l in lines])
        if _DEBUG:
            print('rows', self.rows)
            print('cols', self.cols)
            print(lines)
        self.occupancy_grid = np.zeros((self.rows, self.cols), dtype=np.bool)
        for r in range(self.rows):
            for c in range(self.cols):
                if lines[r][c] == 'x':
                    self.occupancy_grid[r][c] = True
                if lines[r][c] == 'g':
                    self.goal = (r, c)
                elif lines[r][c] == 'i':
                    self.init_pos = (r, c, 0)

    def is_goal(self, s):
        '''
        Test if a specifid state is the goal state

        s - tuple describing the state as (row, col) position on the grid.

        Returns - True if s is the goal. False otherwise.
        '''
        return (s[_X] == self.goal[_X] and
                s[_Y] == self.goal[_Y])

    def transition(self, s, a):
        '''
        Transition function for the current grid map.

        s - tuple describing the state as (row, col) position on the grid.
        a - the action to be performed from state s

        returns - s_prime, the state transitioned to by taking action a in state s.
        If the action is not valid (e.g. moves off the grid or into an obstacle)
        returns the current state.
        '''
        new_pos = list(s[:])
        # Ensure action stays on the board
        if a == 'u':
            if s[_Y] > 0:
                new_pos[_Y] -= 1
        elif a == 'd':
            if s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
        elif a == 'l':
            if s[_X] > 0:
                new_pos[_X] -= 1
        elif a == 'r':
            if s[_X] < self.cols - 1:
                new_pos[_X] += 1
        # added diagonal moves Justin Ngo 9/7/2019
        elif a == 'ne':
            if s[_X] < self.cols - 1 and s[_Y] > 0:
                new_pos[_Y] -= 1
                new_pos[_X] += 1
        elif a == 'nw':
            if s[_X] > 0 and s[_Y] > 0:
                new_pos[_Y] -= 1
                new_pos[_X] -= 1
        elif a == 'sw':
            if s[_X] > 0 and s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
                new_pos[_X] -= 1
        elif a == 'se':
            if s[_X] < self.cols - 1 and s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
                new_pos[_X] += 1
        else:
            print('Unknown action:', str(a))

        # Test if new position is clear
        if self.occupancy_grid[new_pos[0], new_pos[1]]:
            s_prime = tuple(s)
        else:
            s_prime = tuple(new_pos)
        return s_prime
    
    def nonholonomic_transition(self, s, a):
        '''
        Transition function for the current grid map.

        s - tuple describing the state as (row, col, orientation) position on the grid.
        a - the action to be performed from state s

        returns - s_prime, the state transitioned to by taking action a in state s.
        If the action is not valid (e.g. moves off the grid or into an obstacle)
        returns the current state.
        '''
        
        # Justin Ngo 9/14/2019
        """
        So the the state is (y,x,theta)
        0 degrees is pointing up with positive going clock wise
        we have degrees of [0, 45, 90, 135, 180, 225, 270, 315]
        the corresponding representation is [0 - 7]
        """
        
        new_pos = list(s[:])
        
        # Ensure action stays on the board
        if a == 'l': # rotate clockwise = positive
            if s[_T] == 7:
                new_pos[_T] = 0
            else:
                new_pos[_T] = s[_T] + 1
        elif a == 'r': # rotate clockwise = negative
            if s[_T] == 0:
                new_pos[_T] = 7
            else:
                new_pos[_T] = s[_T] - 1
        elif a == 'f': # move forward in the direction facing
            if s[_T] == 0: # up
                if s[_Y] > 0:
                    new_pos[_Y] -= 1
            elif s[_T] == 1: # nw
                if s[_X] > 0 and s[_Y] > 0:
                    new_pos[_Y] -= 1
                    new_pos[_X] -= 1
            elif s[_T] == 2: # w
                if s[_X] > 0:
                    new_pos[_X] -= 1
            elif s[_T] == 3: # sw
                if s[_X] > 0 and s[_Y] < self.rows - 1:
                    new_pos[_Y] += 1
                    new_pos[_X] -= 1
            elif s[_T] == 4: #d
                if s[_Y] < self.rows - 1:
                    new_pos[_Y] += 1
            elif s[_T] == 5: #se
                if s[_X] < self.cols - 1 and s[_Y] < self.rows - 1:
                    new_pos[_Y] += 1
                    new_pos[_X] += 1
            elif s[_T] == 6: # e
                if s[_X] < self.cols - 1:
                    new_pos[_X] += 1
            elif s[_T] == 7: # ne
                if s[_X] < self.cols - 1 and s[_Y] > 0:
                    new_pos[_Y] -= 1
                    new_pos[_X] += 1
              
        else:
            print('Unknown action:', str(a))

        # Test if new position is clear
        if self.occupancy_grid[new_pos[0], new_pos[1]]:
            s_prime = tuple(s)
        else:
            s_prime = tuple(new_pos)
        return s_prime

    def display_map(self, path=[], visited={}, filename=None):
        '''
        Visualize the map read in. Optionally display the resulting plan and visisted nodes

        path - a list of tuples describing the path take from init to goal
        visited - a set of tuples describing the states visited during a search
        filename - relative path to file where image will be saved
        '''
        display_grid = np.array(self.occupancy_grid, dtype=np.float32)

        # Color all visited nodes if requested
        for v in visited:
            display_grid[v[0], v[1]] = _VISITED_COLOR
        # Color path in increasing color from init to goal
        for i, p in enumerate(path):
            disp_col = _INIT_COLOR + _PATH_COLOR_RANGE * (i + 1) / len(path)
            display_grid[p[0], p[1]] = disp_col

        display_grid[self.init_pos[0], self.init_pos[1]] = _INIT_COLOR
        display_grid[self.goal] = _GOAL_COLOR

        # Plot display grid for visualization
        imgplot = plotter.imshow(display_grid)
        # Set interpolation to nearest to create sharp boundaries
        imgplot.set_interpolation('nearest')
        # Set color map to diverging style for contrast
        imgplot.set_cmap('Spectral')
        if filename is not None:
            plotter.savefig(filename)
        plotter.show()

    def uninformed_heuristic(self, s):
        '''
        Example of how a heuristic may be provided. This one is admissable, but dumb.

        s - tuple describing the state as (row, col) position on the grid.

        returns - floating point estimate of the cost to the goal from state s
        '''
        return 0.0
    
    def euclidean_heuristic(self, s):
        '''
        AKA L2 Norm -- pythagorean basically. sqrt((q1 - p1)^2 + (q2-p2)^2)
        s - state (row, col) position
        returns - floating point estimate of the cost to the goal from state s
        
        '''
        q2 = self.goal[_Y]
        q1 = self.goal[_X]
        p1 = s[_X]
        p2 = s[_Y]
        return sqrt((q1 - p1)**2 + (q2 - p2)**2)
        
    def manhattan_heuristic(self, s):
        '''
        AKA L1 Norm --- abs(p1 - q1) + abs(p2 - q2) or taxicab distance
        '''
        q2 = self.goal[_Y]
        q1 = self.goal[_X]
        p1 = s[_X]
        p2 = s[_Y]
        
        return abs(p1 - q1) + abs(p2 - q2)

class SearchNode:
    def __init__(self, s, A, parent=None, parent_action=None, cost=0):
        '''
        s - the state defining the search node
        A - list of actions
        parent - the parent search node
        parent_action - the action taken from parent to get to s
        '''
        self.parent = parent
        self.cost = cost
        self.parent_action = parent_action
        self.state = s[:]
        self.actions = A[:]

    def __str__(self):
        '''
        Return a human readable description of the node
        '''
        return str(self.state) + ' ' + str(self.actions) + ' ' + str(self.parent) + ' ' + str(self.parent_action)

    def __lt__(self, other):
        return self.cost < other.cost


class PriorityQ:
    '''
    Priority queue implementation with quick access for membership testing
    Setup currently to only with the SearchNode class
    '''

    def __init__(self):
        '''
        Initialize an empty priority queue
        '''
        self.l = []  # list storing the priority q
        self.s = set()  # set for fast membership testing

    def __contains__(self, x):
        '''
        Test if x is in the queue
        '''
        return x in self.s

    def push(self, x, cost):
        '''
        Adds an element to the priority queue.
        If the state already exists, we update the cost
        '''
        if x.state in self.s:
            return self.replace(x, cost)
        heapq.heappush(self.l, (cost, x))
        self.s.add(x.state)

    def pop(self):
        '''
        Get the value and remove the lowest cost element from the queue
        '''
        x = heapq.heappop(self.l)
        self.s.remove(x[1].state)
        return x[1]

    def peak(self):
        '''
        Get the value of the lowest cost element in the priority queue
        '''
        x = self.l[0]
        return x[1]

    def __len__(self):
        '''
        Return the number of elements in the queue
        '''
        return len(self.l)

    def replace(self, x, new_cost):
        '''
        Removes element x from the q and replaces it with x with the new_cost
        '''
        for y in self.l:
            if x.state == y[1].state:
                self.l.remove(y)
                self.s.remove(y[1].state)
                break
        heapq.heapify(self.l)
        self.push(x, new_cost)

    def get_cost(self, x):
        '''
        Return the cost for the search node with state x.state
        '''
        for y in self.l:
            if x.state == y[1].state:
                return y[0]

    def __str__(self):
        '''
        Return a string of the contents of the list
        '''
        return str(self.l)


def dfs(init_state, f, is_goal, actions, max_depth):
    '''
    Perform depth first search on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''
    # Justin Ngo - 8/31/2019
    if max_depth is None:
        
        frontier = []  # Search Stack (LIFO => think about like plates your stacking)
        node_0 = SearchNode(init_state, actions)
        visited = set()  # make a new set to keep track of nodes you pop out
        frontier.append(node_0)  # remember you pop a node to reveal children if any
        while len(frontier) > 0:
            # This is DFS so LIFO
            node_i = frontier.pop()
            if node_i.state not in visited:
                visited.add(node_i.state)
                if is_goal(node_i.state):
                    return (backpath(node_i), visited)
                else:
                    for an_action in actions:
                        s_prime = f(node_i.state, an_action)  # s_prime = next state
                        n_prime = SearchNode(s_prime, actions, node_i, an_action)
                        frontier.append(n_prime)
        # print('Visited List when goal not found:')
        # print(visited)
        return None
    else:
        depth = 0
        res = None
        while res is None and depth <= max_depth:
            depth += 1
            res = iddfs(init_state, f, is_goal, actions, depth)
        if res is None:
            print('No Path Found')
            return None
        else:
#            print(depth)
            return res
        



def iddfs(init_state, f, is_goal, actions, max_depth):
    '''
    Perform iterative deepning depth first search (iddfs) on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent
    max_depth - what level to do iddfs.

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''

    # Justin Ngo - 9/3/2019
    # iddfs is common choice for uninformed search method. Since its like bfs being that it is optimal and save space.
    # downside is that it recomputes the top of the tree often.
    frontier = []
    node_0 = SearchNode(init_state, actions)
    visited = {} 
    frontier.append((node_0, 0))
    
    while len(frontier) > 0:
        node_i = frontier.pop()
        ns = node_i[0].state # node state
        nd = node_i[1] # node depth
        
        # if nd > max_depth: # only want to reach depth <= max_depth
            # continue
        # The reason why we we want to have this check is because we don't want to see anything else beyond depth + 1
        
        if ns not in visited or visited[ns] > nd:
            # the reason we are not saving the states that can also be seen is because we only care about states we have seen
            # at the smallest depth.  For instance we have a triangle with vertices a, b and c. if we take path a, b, c that gives 
            # us a depth 2. But if we can get to depth c at a shorter depth taking path a, c with depth 1. We are want to save
            # that and we don't care about another one because we can visit more nodes from there better
            visited[ns] = nd
            if is_goal(ns):
                return (backpath(node_i[0]), visited.keys())
            else:
                for a in actions:
                    s_prime = f(ns, a) 
                    n_prime = SearchNode(s_prime, actions, node_i[0], a)
                    
                    if nd + 1 > max_depth:
                        continue
                    else:
                        frontier.append((n_prime, nd + 1))


    return None


def bfs(init_state, f, is_goal, actions):
    '''
    Perform breadth first search on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''
    # Justin Ngo - 9/2/2019
    frontier = []  # Search (FIFO => Queue, like standing in line)
    node_0 = SearchNode(init_state, actions)
    visited = set()  # make a new list to keep track of nodes you pop out
    frontier.append(node_0)  # remember you pop a node to reveal children if any
    while len(frontier) > 0:
        # This is BFS is FIFO
        node_i = frontier.pop(0)
        if node_i.state not in visited:
            visited.add(node_i.state)
            if is_goal(node_i.state):
                return (backpath(node_i), visited)
            else:
                for an_action in actions:
                    s_prime = f(node_i.state, an_action)  # s_prime = next state
                    n_prime = SearchNode(s_prime, actions, node_i, an_action)
                    frontier.append(n_prime)
    print('Visited List when goal not found:')
    print(visited)
    return None


def uniform_cost_search(init_state, f, is_goal, actions):
    # Justin Ngo - 9/7/2019
    # when expanding a node, add the resulting nodes to the frontier only
#    if not in the visited list:
#        or if in frontier but with a higher cost, then replace it
    
    # UCS expands cheapest node first:
    # Frontier is a priority queue
    # similar to BFS but expands cheapest node first
    # Sums cost along each path
    frontier = PriorityQ()
    n0 = SearchNode(init_state, actions)
    visited = set()
    frontier.push(n0, 0) #node and cost
    
    while frontier.__len__() > 0:
        
        cost = frontier.get_cost(frontier.peak()) # get the cheapest value 
        ni = frontier.pop() # pop cheapest node first
                
        visited.add(ni.state)            
        if is_goal(ni.state):
            print(cost)
            return (backpath(ni), visited)
        else:
            for a in actions:
                if actions is _ACTIONS_NONHOLONOMIC:
                    if a == 'f':
                        if ni.state[_T] % 2 == True: # is this a diagonal?
                            c = 1.5
                        else:
                            c = 1
                    else: # turning is 0.25
                        c = 0.25
                else:
                    if a in _ACTIONS:
                        c = 1
                    else: #diagonal Cost is 1.5
                        c = 1.5
                s_prime = f(ni.state, a)
                n_prime = SearchNode(s_prime, actions, ni, a)
                # if node has not been visited or if in frontier but with higher cost
                # replace that with cheaper cost
                
#                if any(n_prime.state not in v for v in visited): #This snippet is to use to check list/set of tuples
                # for UCS you should not expect to see any other path of the same node at a lower cost
                if s_prime not in visited and s_prime not in frontier:
                    frontier.push(n_prime, cost + c)
                elif frontier.__contains__(n_prime) and frontier.get_cost(n_prime) > cost + c:
                    frontier.replace(n_prime, cost + c)
    return None

def a_star_search(init_state, f, is_goal, actions, h):
    '''
    init_state - value of the initial state
    f - transition function takes input state (s), action (a), returns s_prime = f(s, a)
        returns s if action is not valid
    is_goal - takes state as input returns true if it is a goal state
        actions - list of actions available
    h - heuristic function, takes input s and returns estimated cost to goal
        (note h will also need access to the map, so should be a member function of GridMap)
    '''
    # Justin Ngo 9/9/2019
    ###### PSUEDO CODE IS FOUND ON LECTURE 5 ########### Please refer
    # g(n) = cost of the state n
    # h(n) = best estimate to goal from state n
    # So you pop the estimated cost to goal but when that is done you need
    # to remember the actual cost instead of the estimated cost
    frontier = PriorityQ()
    n0 = SearchNode(init_state, actions)
    visited = {}
    frontier.push(n0, 0) #node and cost
    
    while frontier.__len__() > 0:
        
#        estimated_cost = frontier.get_cost(frontier.peak()) # get the cheapest value 
        ni = frontier.pop() # pop cheapest estimated cost node first
        actual_cost = ni.cost
        
        if ni.state in visited and actual_cost > visited[ni.state]:
            continue
        if is_goal(ni.state):
            print(ni.cost)
            return (backpath(ni), visited.keys())
        visited[ni.state] = actual_cost
        for a in actions:
            if actions is _ACTIONS_NONHOLONOMIC:
                    if a == 'f':
                        if ni.state[_T] % 2 == True: # is this a diagonal?
                            c = 1.5
                        else:
                            c = 1
                    else: # turning is 0.25
                        c = 0.25
            else:
                if a in _ACTIONS:
                    c = 1
                else: #diagonal Cost is 1.5
                    c = 1.5
            s_prime = f(ni.state, a)
            # combined cost p(n) = g(n) + h(n)
            g = actual_cost + c
            heu = h(s_prime)
            p = g + heu
            n_prime = SearchNode(s_prime, actions, ni, a, g)
            # if node has not been visited or if in frontier but with higher cost
            # replace that with cheaper cost
            
#                if any(n_prime.state not in v for v in visited): #This snippet is to use to check list/set of tuples
            # For A* you have a check to see if it is in visited and if that visted cost > what the actual cost is now
            # then add it since the combined cost can throw you off. like in the case of a barrier
            if s_prime in visited and visited[s_prime] > g or s_prime not in visited and s_prime not in frontier:
                frontier.push(n_prime, p)
                
            # have to change from ucs on the contain because i'm now saving the 
            # cost inside the search node so the cost could be different than 
            # previous so it migh tnot find
            elif s_prime in frontier and frontier.get_cost(n_prime) > p:
                frontier.replace(n_prime, p)
    return None



def backpath(node):
    '''
    Function to determine the path that lead to the specified search node

    node - the SearchNode that is the end of the path

    returns - a tuple containing (path, action_path) which are lists respectively of the states
    visited from init to goal (inclusive) and the actions taken to make those transitions.
    '''
    path = []
    action_path = []
    # Justin Ngo 8/31/2019
    n = node
    while n.parent is not None:
        path.insert(0, n.state)
        action_path.insert(0, n.parent_action)
        n = n.parent
        if n.parent is None:
            path.insert(0, n.state)
            action_path.insert(0, None)
    return (path, action_path)
