Project 3: Planning with Uncertainty
CS 6370 / ME EN 6225 Motion Planning 
University of Utah

Justin Ngo, u0453732
Nov/7/2019
***********************************************************
Software
***********************************************************
spyder 
python 3.8

***********************************************************
Files
***********************************************************
probabilistic_planning.py
map0.txt
map1.txt
map2.txt
README.txt

***********************************************************
How To Run. NOTE: all sections are labeled in the '__main__'
***********************************************************
General guidlines:
1. open up the python file in spyder and just comment/uncomment and fill out parameters in the '__main__'

General Variables to change:
test_map --> any map in the files section. i.e. './map0.txt' 
action_type --> 0 for cardinal direction only, 1 for cardianal + diagonal
transition probabilites --> i.e. tp0, its in the form (correct action probability, diagonal probability, cardinal probability)
The transition probabilites need to be add up to 1. for example. 0.7 + 0.1*2 + 0.05*2 = 1     
    #tp0 = (1, 0 , 0)
    #tp1 = (0.8, 0, 0.1)
    #tp2 = (0.6, 0, 0.2)
    #tp3 = (0.8, 0.1, 0)
    #tp4 = (0.7, 0.1, 0.05)

Section 1: Markov Decision Process (MDP)
1. in the main uncomment run_bfs
2. If you want to see deterministic then set the variable display_stochastic = False
3. change the transition probabilies if you want only affects when display_stochastic = True
4. Then hit run.

Section 2: Value iteration
1. uncomment run_value_iteration in the '__main__'
2. you can change everything same as MDP besides display_stochastic and a new argument called 'scenario'
3. the variable scenario changes how each states reward is set
    # scenario = 0 => goal +10, everything else = 0
    # scenario = 1 => goal +1, everything else = 0
    # scenario = 2 => goal +10, everything else = -1
    # scenario = 3 => goal +10, corners -5, everything else = 0
4. Just hit run.

Section 3: Policy Iteration
1. Again, the basic variables can be changed but now there is an new varible called initial_policy
2. The variable initial_policy defaults to None which corresponds to random initial policy
initial_policy 
- None => random initial policy
- or anything in the action set. i.e. if action_set = 0 => {'u','d', 'l', 'r'} then you can pick any of those actions to set
all states to have the initial policy of that action. i.e. 'u' would correspond to the up policy for all action
3. Just hit run