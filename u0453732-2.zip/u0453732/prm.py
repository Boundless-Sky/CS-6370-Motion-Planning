#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Probabilistic Roadmaps (PRMs)
Author: Justin Ngo
Date: 10/17/2019

"""
import numpy as np
import matplotlib.pyplot as plotter
from math import pi, sqrt
from collisions import PolygonEnvironment
import time
from rrt import RRT


class Node:
    def __init__(self, state, parent=None):
        self.state = state
        self.children = []
        self.parent = parent

    def add_child(self, child):
        self.children.append(child)
               
class PRMSearch:
    def __init__(self):
        self.vertices = []
        self.edges = []

    def get_states_and_edges(self):
        return (self.vertices, self.edges)
    
class PRM:
    def __init__(self, num_samples, num_dimensions=2, radius=1, lims = None, 
                 collision_func=None):
        """
        Initalize PRM instance 
        """
        
        self.K = num_samples
        self.n = num_dimensions
        self.radius = radius
        
        self.in_collision = collision_func
        if collision_func is None:
            self.in_collision = self.fake_in_collision
        
        # Setup range limits
        self.limits = lims
        if self.limits is None:
            self.limits = []
            for n in range(num_dimensions):
                self.limits.append([0,100])
            self.limits = np.array(self.limits)
            
        self.ranges = self.limits[:,1] - self.limits[:,0]
        self.found_path = False
    
    def sample(self):
        '''
        Sample a new configuration and return
        JN 10/18/2019
        '''
        q = []
        # limits are saved as [min max]
        for i in range(self.n):
            min_lim = self.limits[i, 0]
            max_lim = self.limits[i, 1]
            # float samples
            q.append((np.random.random()*(max_lim - min_lim)) + min_lim)
        # int samples
        # sample.append(np.random.randint(min_lim, max_lim))
        return np.array(q)
    
    def build_roadmap(self): # build the map of enviornment       
        # initalize 'T' so collisions.py can draw enviornment
        self.T = PRMSearch()
        
        # initialize a graph with vertices and edges
        self.V = [] # vertices
        self.E = [] # edges, (parent, child)
                
        # randomly sample 'configuration q' among the space and check if point in collision
        # bad part is if enviornment changes so you would have to resample
        while len(self.V) < self.K:
            q = self.sample()
            if self.in_collision(q) != True:
                self.V.append(q)
        
        # connect the vertices
        for q in self.V:
           # find all vertices in a radius. Can change to number of vertices later
           # speed by using Kd-Tree for searching nearest neighbors
           nearest = self.Rdist(q)
           if len(nearest) > 0:    
               # Local planner (straight line or RRT basic)
               for q_prime in nearest:
                   collides = self.in_collision(q_prime, q)
                   if collides == False and self.check_array((q, q_prime)) == False:
                       self.E.append((q, q_prime))
        
        self.T.vertices = self.V
        self.T.edges = self.E
        
    def build_roadmap_RRT(self, polyenv): # build the map of enviornment       
        # initalize RRT
        pe = polyenv
        pe.read_env(env)
        dims = len(pe.start)
        # of samples
        rrt_sample = 50
        rrt = RRT(rrt_sample,
                  dims,
                  step_length = 2,
                  lims = pe.lims,
                  connect_prob = 0.05, #percentage in decimal
                  collision_func=pe.test_collisions)
        
        # initalize 'T' so collisions.py can draw enviornment
        self.T = PRMSearch()
        
        # initialize a graph with vertices and edges
        self.V = [] # vertices
        self.E = [] # edges, (parent, child)
         
        # randomly sample 'configuration q' among the space and check if point in collision
        # bad part is if enviornment changes so you would have to resample
        while len(self.V) < self.K:
            q = self.sample()
            if self.in_collision(q) != True:
                self.V.append(q)
        
        # connect the vertices
        rrt_vert = []
        for q in self.V:
           # find all vertices in a radius. Can change to number of vertices later
           # speed by using Kd-Tree for searching nearest neighbors
           nearest = self.Rdist(q)
           if len(nearest) > 0:    
               # Local planner (straight line or RRT basic)
               for q_prime in nearest:
#                   collides = self.in_collision(q_prime, q)
                   plan = rrt.build_rrt(q, q_prime)
#                   plan = rrt.build_bidirectional_rrt_connect(q, q_prime)
                   if plan != None:
                       node_rrt, edge_rrt = rrt.T.get_states_and_edges()
                       rrt_vert.extend(node_rrt)
                       self.E.extend(edge_rrt)
#                   if collides == False and self.check_array((q, q_prime)) == False:
#                   self.E.append((q, q_prime))
        
        self.V.extend(rrt_vert)
        self.T.vertices = self.V
        self.T.edges = self.E
    
    def check_array(self, sample_config):
        # returns false if that configuration hasn't been seen
        # TODO: try instead of array_equal, use all close for floats
        return next((True for elem in self.E if np.array_equal(sample_config, elem)), False)
                    
    def Rdist(self, q):
        nn = [] # list of nearest neighbors for given radius
        for q_prime in self.V:
            d = np.linalg.norm(q_prime - q)
            if d <= self.radius and d != 0:
                nn.append(q_prime)
        return nn
        
    def query_roadmap(self, initial, goal): # using that map, find path from initial to goal               
        # add inital and goal nodes and connect them to the nearest nodes
        # TODO: A better may be just to find the 'N' nearest vertices and add instead of distance
        self.start = np.array(initial)
        self.finish = np.array(goal)
        
        self.V.append(self.start)
        self.V.append(self.finish)
        
        near_initial = self.Rdist(self.start)
        near_goal = self.Rdist(self.finish)
        
        if len(near_initial) == 0 or len(near_goal) == 0:
            print('Increase radius to connect start/goal to roadmap')
            return None
        
        connection_made = False
        for q_prime in near_initial:
            collides = self.in_collision(q_prime, self.start)
            if collides == False:
                self.E.append((self.start,q_prime))
                connection_made = True
        if connection_made == False:
            print('No connection can be made from start to roadmap. Try increasing radius or another initial')
            return None
        
        connection_made = False
        for q_prime in near_goal:
            collides = self.in_collision(q_prime, self.finish)
            if collides == False:
                self.E.append((q_prime, goal))
                connection_made = True
        if connection_made == False:
            print('No connection can be made from goal to roadmap. Try increasing radius or another goal')
            return None
        
        
        # find least cost path with distance between nodes being the cost
        path = self.shortest_path()
        if path != None:
            self.T.vertices = self.V
            self.T.edges = self.E
            return path
        return None
    
    def fake_in_collision(self, q):
        '''
        We never collide with this function!
        '''
        return False
    
    def shortest_path(self):
        # TODO: Dijkstra's Algorithm
        node0 = Node(self.start)
        frontier = []
        visited = set()
        frontier.append(node0)
        
        while len(frontier) > 0:
            #BFS, see my graph_search in project 1
            node_i = frontier.pop(0)
            if tuple(node_i.state) not in visited:
                visited.add(tuple(node_i.state))
                if (tuple(node_i.state) == tuple(self.finish)):
                    return self.get_back_path(node_i)
                
#                edges_associated = [tuple(edge) for tuple(edge) in self.E if any((node_i.state == edge).all() for edge in self.E)]
#                edges_associated = [tuple(edge) for tuple(edge) in self.E if any((node_i.state == edge).all())]
#                edges_associated = []
                nodes_associated = []
                for edges in self.E:
                    e = list(edges)
                    e1 = e[0]
                    e2 = e[1]
                    if tuple(node_i.state) == tuple(e1):
                        nodes_associated.append(e2)
                    elif tuple(node_i.state) == tuple(e2):
                        nodes_associated.append(e1)
                        
#                        edges_associated.append(edges)
#                ea = list(edges_associated) #flatten the tuples
#                nodes_associated = [tuple(x) for x in ea if tuple(x) != tuple(node_i.state)]
                
                for next_node in nodes_associated:
                    frontier.append(Node(next_node, node_i))
        return None            

    def get_back_path(self, n):
        path = []
        while n.parent is not None:
            path.append(n.state)
            n = n.parent
        path.append(n.state) #JN 10/16/2019, add the start (makes start hard to see)
        path.reverse()
        return path
    
def euclidean_dist(s): # 's' a tuple with 2 points
    q2 = s[0][1]
    q1 = s[0][0]
    p1 = s[1][0]
    p2 = s[1][1]
    return sqrt((q1 - p1)**2 + (q2 - p2)**2)

def prm_roadmap(num_samples=500, radius=2, env='./env0.txt'):
    '''
    num_samples - number of samples to generate with PRM
    radius - radius for determining near neighbors, TODO: instead of radius, N closest neighbors
    env         - enviornment map
    '''
    pe = PolygonEnvironment()
    pe.read_env(env)

    dims = len(pe.start)
    start_time = time.time()

    prm = PRM(num_samples, 
              dims, 
              radius,
              lims = pe.lims,
              collision_func = pe.test_collisions)
    
    prm.build_roadmap()
    run_time = time.time() - start_time
    print('run_time =', run_time)
    return prm

def prm_roadmap_RRT(num_samples=500, radius=2, env='./env0.txt'):
    '''
    num_samples - number of samples to generate with PRM
    radius - radius for determining near neighbors, TODO: instead of radius, N closest neighbors
    env         - enviornment map
    '''
    pe = PolygonEnvironment()
    pe.read_env(env)

    dims = len(pe.start)
    start_time = time.time()

    prm = PRM(num_samples, 
              dims, 
              radius,
              lims = pe.lims,
              collision_func = pe.test_collisions)
    
    prm.build_roadmap_RRT(pe)
    run_time = time.time() - start_time
    print('run_time =', run_time)
    return prm

if __name__ == '__main__':
    n = 600 # samples
    r = 13  # straight line local planner 
            # env0 = r=13, n = 600
            # env1 = r= 1, n = 600
            
            # rrt local planner
            # n = 100
            # r = 13
            
    env = './env0.txt'
    
    plan = None
    pe = PolygonEnvironment()
    pe.read_env(env)
    
    prm = prm_roadmap(n, r, env)
#    prm = prm_roadmap_RRT(n, r, env)
    
    # initalize another prm that will be altered so something like
    # prm_these_goals = prm
    # that way prm has same foundational road map and you don't mess with it
    pe.draw_plan(plan, 
                 prm, 
                 dynamic_tree=False, 
                 dynamic_plan=True, 
                 show=True,
                 draw_start_goal=False,
                 ws_draw=False)
#    plotter.pause(3)
#    plotter.close()
    
    # save original roadmap
#    prmA = prm
#    prmB = prm
#    prmC = prm
    
    # enviornment 0 
#    pathA = prmA.query_roadmap(pe.start, pe.goal)
#    pathB = prmA.query_roadmap(np.array([50, 125]),np.array([-25, 0]))
#    pathC = prmA.query_roadmap(np.array([-100, 150]), np.array([100,-50]))

    # environment 1
#    pathA = prmA.query_roadmap(pe.start, pe.goal)
#    pathB = prmA.query_roadmap(np.array([1.57, 0, 0]),np.array([-0.4, -1.57, -0.785]))
#    pathC = prmA.query_roadmap(np.array([3.14, -1.57, 0]), np.array([3.14, 1.57, 0]))
#    pe.draw_plan(pathA, 
#                 prmA, 
#                 dynamic_tree=False, 
#                 dynamic_plan=True, 
#                 show=True,
#                 draw_start_goal=True,
#                 ws_draw=False)
#    pe.draw_plan(pathB, 
#                 prmB, 
#                 dynamic_tree=False, 
#                 dynamic_plan=True, 
#                 show=True,
#                 draw_start_goal=True,
#                 ws_draw=False)
#    pe.draw_plan(pathC, 
#                 prmC, 
#                 dynamic_tree=False, 
#                 dynamic_plan=True, 
#                 show=True,
#                 draw_start_goal=True,
#                 ws_draw=False)
    
    