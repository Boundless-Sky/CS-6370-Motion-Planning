#!/usr/bin/env python
'''
Package providing helper classes and functions for performing graph search operations for planning.

JN 10/17/2019
Rapidly-Exploring Random Trees (RRTs)
'''
import numpy as np
import matplotlib.pyplot as plotter
from math import pi
from collisions import PolygonEnvironment
import time

_DEBUG = False

_TRAPPED = 'trapped'
_ADVANCED = 'advanced'
_REACHED = 'reached'

class TreeNode:
    def __init__(self, state, parent=None):
        self.state = state
        self.children = []
        self.parent = parent

    def add_child(self, child):
        self.children.append(child)

class RRTSearchTree:
    def __init__(self, init):
        self.root = TreeNode(init)
        self.nodes = [self.root]
        self.edges = []

    def find_nearest(self, s_query):
        min_d = 1000000
        nn = self.root
        for n_i in self.nodes:
            d = np.linalg.norm(s_query - n_i.state)
            if d < min_d:
                nn = n_i
                min_d = d
        return (nn, min_d)

    def add_node(self, node, parent):
        self.nodes.append(node)
        self.edges.append((parent.state, node.state))
        node.parent = parent
        parent.add_child(node)

    def get_states_and_edges(self):
        states = np.array([n.state for n in self.nodes])
        return (states, self.edges)

    def get_back_path(self, n):
        path = []
        while n.parent is not None:
            path.append(n.state)
            n = n.parent
#        path.append(n.state) #JN 10/16/2019, add the start (makes start hard to see)
        path.reverse()
        return path

class RRT:

    def __init__(self, num_samples, num_dimensions=2, step_length = 1, lims = None,
                 connect_prob = 0.05, collision_func=None):
        '''
        Initialize an RRT planning instance
        '''
        self.K = num_samples
        self.n = num_dimensions
        self.epsilon = step_length
        self.connect_prob = connect_prob

        self.in_collision = collision_func
        if collision_func is None:
            self.in_collision = self.fake_in_collision

        # Setup range limits
        self.limits = lims
        if self.limits is None:
            self.limits = []
            for n in range(num_dimensions):
                self.limits.append([0,100])
            self.limits = np.array(self.limits)

        self.ranges = self.limits[:,1] - self.limits[:,0]
        self.found_path = False

    def build_rrt(self, init, goal):
        '''
        Build the rrt from init to goal
        Returns path to goal or None
        '''
        self.goal = np.array(goal)
        self.init = np.array(init)
        self.found_path = False

        # Build tree and search
        self.T = RRTSearchTree(init)
        # Justin Ngo - 10/1/2019
        # See Lecture 11 - RRT (Basic RRT algorithm)
        for k in range(self.K):
            self.extend(self.sample())
            
            if self.found_path == True:
                break
            
        if self.found_path == False:
            return None
        else:
            return self.T.get_back_path(self.T.nodes[-1])


    def build_rrt_connect(self, init, goal):
        '''
        Build the rrt connect from init to goal
        Returns path to goal or None
        '''
        self.goal = np.array(goal)
        self.init = np.array(init)
        self.found_path = False

        # Build tree and search
        self.T = RRTSearchTree(init)
        # Justin Ngo - 10/16/2019 
        
        u = _TRAPPED # 'u' is state of extend
        q = np.array(init)
        for k in range(self.K):
            if u == _TRAPPED:
                q = self.sample()
                u = self.extend(q) 
                continue
            if u == _ADVANCED:
                u = self.extend(q)
                continue
            if u == _REACHED and self.found_path == True:
                break
            else: 
                u = _TRAPPED
            
        if self.found_path == False:
            return None
        else:
            return self.T.get_back_path(self.T.nodes[-1])
    
    def build_bidirectional_rrt_connect(self, init, goal):
        """
        Build the bidrectional RRT connect from both init and goal
        Returns path to goal or None
        """

        self.found_path = False
        
        # build tree from both init and goal and search
        self.Ta = RRTSearchTree(init) # tree A, start from initial
        self.Tb = RRTSearchTree(goal) # tree B, start from goal
        
        self.T = self.Ta # start with Tree A
        self.tree = 'a'
        
        #this needs to be different for each tree
        self.goal = np.array(goal)
        self.init = np.array(init)
        
        u = _ADVANCED
        
        k = 0
        while k < self.K:
            q = self.sample();
    
            if self.extend(q) != _TRAPPED:
                q_target = self.T.nodes[-1]
                self.swap_tree(init,goal,Use_Smaller = False)
                
                while u == _ADVANCED:
                    u = self.extend(q_target.state)
                    if k >= self.K: # ran out of samples
                        break
                    k += 1
                    self.update()
                if u == _TRAPPED:
                    u = _ADVANCED # reset state of extend 'u'
                    k += 1
                    self.update()
                    continue
                elif u == _REACHED:
                    self.update()
                    # Find path
                    path = self.bidir_path()
                    path.append(np.array(goal))
                    # make into one tree from two
                    self.T = self.Ta
                    self.T.nodes.extend(self.Tb.nodes) #this is python's built in extend
                    self.T.edges.extend(self.Tb.edges) #this is python's built in extend
                    return path
                
            self.swap_tree(init,goal,Use_Smaller = False)    
            k += 1
            
        # make into one tree from two
        self.T = self.Ta
        self.T.nodes.extend(self.Tb.nodes) #this is python's built in extend
        self.T.edges.extend(self.Tb.edges) #this is python's built in extend      
        return None
    
    def bidir_path(self):
        # get path from where both reaches and append togeter.
        pathA = self.Ta.get_back_path(self.Ta.nodes[-1])
        pathB = self.Tb.get_back_path(self.Tb.nodes[-1])
        pathB.reverse()
        del pathA[-1]
        pathA.extend(pathB)   
        return pathA
    
    def update(self):
        if self.tree == 'a':
            self.Ta = self.T
        else:
            self.Tb = self.T

    def swap_tree(self, init, goal, Use_Smaller=False):
        
        # Swap for smaller tree
        if Use_Smaller == True:
            if self.tree == 'a':
                self.Ta = self.T
            else:
                self.Tb = self.T
                    
            len_Ta = len(self.Ta.nodes)
            len_Tb = len(self.Tb.nodes)
            if len_Ta <= len_Tb:
                self.T = self.Ta
                self.tree = 'a'
                self.goal = np.array(goal)
                self.init = np.array(init)
                return None
            else:
                self.T = self.Tb
                self.tree = 'b'
                self.goal = np.array(init)
                self.init = np.array(goal)
                return None
            
        # Regular Swap   
        if self.tree == 'a':
            self.Ta = self.T
            self.tree = 'b'
            self.T = self.Tb
            self.goal = np.array(init)
            self.init = np.array(goal)
        else:
            self.Tb = self.T
            self.tree = 'a'
            self.T = self.Ta
            self.goal = np.array(goal)
            self.init = np.array(init) 
                   
        return None #not having this implicitly returns none 
        
    def sample(self):
        '''
        Sample a new configuration and return
        '''
        # Return goal with connect_prob probability
        # Justin Ngo - 10/1/2019
        
        # generate a random number with connect_prob probability of 
        # choosing the goal and return else randomly generate sample and return that
        
#        if np.random.random() <= self.connect_prob: 
#            return self.goal
#        else:
#            # get the config space limtis and the number of dimensins 
#            # i.e if its a 2d coordinate. then sample x and then y and then spit
#            # back the coordinate but if its higher dimensions then plan accordingly.
#            # send back the info of the sample in the same order (i.e if its (y,x) pair then 
        if np.random.random() <= self.connect_prob:
            return self.goal
        else:
            sample = []
            # limits are saved as [min max]
            for i in range(self.n):
                min_lim = self.limits[i, 0]
                max_lim = self.limits[i, 1]
                # float samples
                sample.append((np.random.random()*(max_lim - min_lim)) + min_lim)
                # int samples
#                sample.append(np.random.randint(min_lim, max_lim))
        return np.array(sample)
    

    def extend(self, q):
        '''
        Perform rrt extend operation.
        q - new configuration to extend towards
        '''
        # Justin Ngo 10/16/2019
        # find Node in Tree nearest to sample point 'q'
        x_near, min_d = self.T.find_nearest(q) # if you just want one output x_near = self.T.find_nearest(q)[0]
        
        # is goal/sample within some radius
        goal_d = np.linalg.norm(self.goal - x_near.state)
        if goal_d <= min_d and goal_d <= self.epsilon:
            new_state = self.goal
        elif min_d <= self.epsilon:
            new_state = q
        else:
            # create unit vector and add to the x_near.state
            new_state = self.epsilon*((q - x_near.state)/min_d) + x_near.state
                    
#        if self.in_collision(new_state, x_near.state) != True: #more robust collision checker but takes longer
        if self.in_collision(new_state) != True:
        # create a new node from x_near to q.
            x_new = TreeNode(new_state, x_near)
            self.T.add_node(x_new, x_near) # adds both vertex and edge
            
            if (x_new.state == self.goal).all():
                self.found_path = True
                return _REACHED # reached node of interest
            if (new_state == q).all():
                return _REACHED
            else:
                return _ADVANCED # continue to use the same sample
        
        return _TRAPPED # can't move anymore

    def fake_in_collision(self, q):
        '''
        We never collide with this function!
        '''
        return False

def test_rrt_env(num_samples=500, step_length=2, env='./env0.txt', connect=False, bidirection=False):
    '''
    create an instance of PolygonEnvironment from a description file and plan a path from start to goal on it using an RRT

    num_samples - number of samples to generate in RRT
    step_length - step size for growing in rrt (epsilon)
    env - path to the environment file to read
    connect - If True run rrt_connect
    bidirection - If True run bidirectional RRT 
    
    returns plan, planner - plan is the set of configurations from start to goal, planner is the rrt used for building the plan
    '''
    pe = PolygonEnvironment()
    pe.read_env(env)

    dims = len(pe.start)
    start_time = time.time()

    rrt = RRT(num_samples,
              dims,
              step_length,
              lims = pe.lims,
              connect_prob = 0.05, #percentage in decimal
              collision_func=pe.test_collisions)
    if bidirection:
        plan = rrt.build_bidirectional_rrt_connect(pe.start, pe.goal)
    elif connect:
        plan = rrt.build_rrt_connect(pe.start, pe.goal)
    else:
        plan = rrt.build_rrt(pe.start, pe.goal)
    run_time = time.time() - start_time
    print('plan:', plan)
    print('run_time =', run_time)
    return plan, rrt

if __name__ == '__main__':
    num_samples = 500
    step_length = 2 # epsilon, step 2 for env0, step 0.15
    
    environment = './env0.txt'
#    environment = './env0_JN01.txt'
#    environment = './env0_JN02.txt'
#    environment = './env0_JN03.txt'
    
#     Environment 1: start/goal is in radians
#    environment = './env1.txt'
#    environment = './env1_JN01.txt'
#    environment = './env1_JN02.txt'
#    environment = './env1_JN03.txt'
    
    connect = True
    bidirection = True
    plan, rrt = test_rrt_env(num_samples, step_length, environment, connect, bidirection)
    pe = PolygonEnvironment()
    pe.read_env(environment)
    pe.draw_plan(plan,rrt, dynamic_tree=False, dynamic_plan=True, show=True)