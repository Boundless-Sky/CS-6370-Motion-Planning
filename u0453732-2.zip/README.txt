Justin Ngo 10/18/2019
Project 2: Sampling Based Planning
CS 6370 / ME EN 6225 Motion Planning, U OF U

**********************************
*********** Files ****************
**********************************
collisions.py
rrt.py
prm.py
lbr4_testscript.py
vrerpWrapper.py
test.py
env0.txt
env0_JN01.txt
env0_JN02.txt
env0_JN03.txt
env1.txt
env1_JN01.txt
env1_JN02.txt
env1_JN03.txt
vrepfiles

**********************************
*********** How to run ***********
**********************************
Program used: spyder, Vrep edu

Have files in one folder

**********************************
*********** RRT ******************
**********************************
1) open rrt.py in spyder
2) in the main change/comment
- num_samples (number of samples, 500 is good)
- step_length (2 for env0, 0.15 for env1 are good numbers)
- environment (just comment/uncomment ones interested, env0.txt should be current uncommented)
- connect (True to turn on RRT connect, False for basic RRT) *NOTE: bidirection must equal False!
- bidirection (True to use Bidirectional RRT connect, False to enable the basic rrt or rrt connect)

3) just hit file run (f5) and graph with dynamic plan will pop up

**********************************
************ PRM *****************
**********************************
1) open prm.py in spyder
2) in main, change/comment to get desired affects when running 
- n ( number of samples to use with PRM)
- r ( radius for Rdist to check nearest neigbors)
----good values for n and r -----
# straight line local planner 
	# env0 = r=13, n = 600
	# env1 = r= 1, n = 600
            
# rrt local planner
	# env0 # n = 100 # r = 13

- env (environement map, change to anything in folder. i.e './env0.txt' and './env1.txt')

---- changing local planners (straight or rrt basic) -------
comment/uncomment 
prm_roadmap = straight line local planner
prm_roadmap_RRT = rrt basic local planner

------ saving original road map and planning adding start and goal nodes and plan -------
uncomment/comment
#    prmA = prm
#    prmB = prm
#    prmC = prm

then uncomment the corresponding path and draw_plan function

i.e
prmA = prm
pathA = prmA.query_roadmap(pe.start, pe.goal) 
pe.draw_plan(pathA, prmA, dynamic_tree=False, dynamic_plan=True, show=True, draw_start_goal=True, ws_draw=False)

**NOTE** pe.start, pe.goal can be subsitiuded for your own start/goal just keep in mind the shape. in the commented out code,
there are examples of how to do your own start/goal.

**********************************
************ Vrep ****************
**********************************
1) open test.py in spyder
2) change these variables to suit your needs
- connect (True to turn on RRT connect, False for basic RRT) *NOTE: bidirection must equal False!
- bidirection (True to use Bidirectional RRT connect, False to enable the basic rrt or rrt connect)
3) save
4) open up vrep -> open scene -> ./vrepfiles/vrepfiles/lbr4_environment.ttt
5) double click on test.py and it should connect and run and display lines in vrep

6) OR! you can just change variables in spyder (step 2) and then hit run file (f5) in spyder and it works the same as save -> double click














****************************************************************************************************************************************
************************************************ Notes 2 self **************************************************************************
****************************************************************************************************************************************

Yes this is correct. The random lines and points being visualized should be the only output on VREP running the lbr4_testscript.

If you would like to see an arm trajectory it should be straight forward as well. The runTrajectory method expects a 2 dimension structure of shape, (X,7) where X is how many points are on trajectory and 7 is joints on the arm. The values should all be between -pi and pi.

For example this should generate a trajectory you can send to runTrajectory.

singleJoint = np.linspace(0,np.pi,100)

fullTraj = np.reshape(np.repeat(singleJoint,7),(100,7))

GRIFFIN TABOR
HW2 various visualization issues
GRIFFIN TABOR
No unread replies.No replies.
1. Several students have had issues with

plotter.hold(True)

If trying to call draw functions throws an error related to plotter.hold feel free to delete it, as it is unnecessary. Issue is from different versions of matplotlib for python3 not having the function

2. The default visualization code all assumes a single Tree when visualizing. For bidirectional the answer key just puts the 2 trees together at the end for visualization. You may find this helpful 

self.T = self.T_init
self.T.nodes.extend(self.T_goal.nodes)
self.T.edges.extend(self.T_goal.edges)